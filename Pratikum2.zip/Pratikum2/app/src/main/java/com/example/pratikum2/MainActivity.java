package com.example.pratikum2;

import android.graphics.Paint;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private TextView tv01, tv02, tv03, tv04;
    private Typeface mytype01, mytype02, mytype03, mytype04;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv01 = findViewById(R.id.tv1);
        mytype01 = Typeface.createFromAsset(getAssets(),"fonts/Montserrat-SemiBold.ttf");
        tv01.setTypeface(mytype01);

        tv02 = findViewById(R.id.tv2);
        mytype02 = Typeface.createFromAsset(getAssets(),"fonts/Montserrat-ExtraLight.ttf");
        tv02.setTypeface(mytype02);

        tv03 = findViewById(R.id.tv3);
        mytype03 = Typeface.createFromAsset(getAssets(),"fonts/Montserrat-SemiBold.ttf");
        tv03.setTypeface(mytype03);

        tv04 = findViewById(R.id.tv4);
        mytype04 = Typeface.createFromAsset(getAssets(),"fonts/Montserrat-SemiBold.ttf");
        tv04.setTypeface(mytype04);

        tv03 = findViewById(R.id.tv5);
        tv03.setPaintFlags(tv03.getPaintFlags()| Paint.UNDERLINE_TEXT_FLAG);
    }
}
